Password: reconstructer.org

25.11.2013

A new version of Officemalscanner/RTFScan has been released. This update includes a generic decryption loop detection, enhanced shellcode patterns and bugfixes. Enjoy!


12.09.2012

The new version of the OfficeMalScanner suite introduces RTFScan. As you might know, there are several samples in the wild, using the RTF format as OLE and PE-File container. So here is a very first version of RTFScan. It currently is able to scan for malicious traces like shellcode, dumps embedded OLE and PE files and other data containers. Buffer decryption in RTFScan is not supported in this release, as OMS and RTFScan will be enhanced to a cryptanalysis feature to break keys up to 1024 bytes in seconds. The old brute force feature in OMS will be kicked then.


10.08.2012

I found some time to update OfficeMalScanner lately. So here is Version 0.54! Next to bugfixes, it now has its own RtlDecompressBuffer library to support VB-macro extraction on WINE. Further the document format is detected (word, ppt, excel) and is able to extract embedded flash files (compressed and uncompressed).

